function init () {
	var hStart = document.getElementById('start');
	hStart.onclick = startNow;
}

function startNow () {
	oClock.seconds = parseInt(document.getElementById('duration').value,10);
	oClock.updateclock(); // om de beginwaarde juist te zetten.
	clearInterval(oClock.interval);
	oClock.interval = setInterval(countdown,1000);
}

function countdown () {
	oClock.telaf();
	oClock.updateclock();
}

var oClock = {
	seconds: 0,
	interval: null,
	telaf: function  () {
		if (this.seconds > 0) {
			this.seconds = this.seconds -1;
			console.log(this.seconds);
		};
	},	
	updateclock: function  () {
		var cLocation = ((150*this.seconds)-150) + "px -" + (150*this.seconds) + "px";
		document.getElementById('clock').style.backgroundPosition=cLocation;
	}
};

window.onload = init;