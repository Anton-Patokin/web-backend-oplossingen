<?php $__env->startSection('content'); ?>
  <div class="container">
    <hgroup>
      <h1>Maak nieuwe todo</h1>
      <a href="/todo">Terug</a>
    </hgroup>
    <br />
    <?php echo Form::open(array("action" => "TodoController@create")); ?>

      <fieldset class="form-group">
        <?php echo Form::text('text', null, array('class' => 'form-control')); ?>

      </fieldset>
      <fieldset class="form-group">
        <?php echo Form::submit('Maak Todo', array('class' => 'btn btn-primary')); ?>

      </fieldset>
    <?php echo Form::close(); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>