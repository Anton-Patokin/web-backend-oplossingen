<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="jumbotron">
    <h1 class="display-3">Welkom bij de todo applicatie!</h1>
    <p class="lead">Todo's nu heel simpel!</p>
    <p class="lead">
      <a class="btn btn-primary btn-lg" href="todo/" role="button">Start</a>
    </p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>