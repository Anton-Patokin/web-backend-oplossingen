<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <link rel="stylesheet" href="<?php echo e(asset('/css/vendor/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>"/>
    <?php echo $__env->yieldContent('style'); ?>
    <title>Welkom</title>
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-static-top">
      <a class="navbar-brand" href="/">Todo</a>
      <ul class="nav navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="/todo">Todo's <span class="sr-only">(current)</span></a>
        </li>
      </ul>
    </nav>
    <div class="clearfix"></div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer">
      Copyright, <a href="http://www.webmagico.be/">Webmagico
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
