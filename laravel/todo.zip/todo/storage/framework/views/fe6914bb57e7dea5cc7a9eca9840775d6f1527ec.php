<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>Todo's</h1>
    <?php if(Session::get("error")): ?>
      <div class="alert alert-danger"><?php echo e(Session::get("error")); ?>

    <?php endif; ?>
    <h2>Te doen</h2>
    <ul>
      <?php foreach($todos as $todo): ?>
        <?php if(!$todo->done): ?>
          <li><?php echo e($todo->text); ?> - <a href="/todo/delete/<?php echo e($todo->id); ?>">Verwijder</a> - <a href="/todo/done/<?php echo e($todo->id); ?>">Gedaan</a></li>
        <?php endif; ?>
      <?php endforeach; ?>
    </ul>
    <h2>Klaar</h2>
    <ul>
      <?php foreach($todos as $todo): ?>
        <?php if($todo->done): ?>
          <li><?php echo e($todo->text); ?>- <a href="/todo/delete/<?php echo e($todo->id); ?>">Verwijder</a> - <a href="/todo/notdone/<?php echo e($todo->id); ?>">Niet gedaan</a></li>
        <?php endif; ?>
      <?php endforeach; ?>
    </ul>
    <a href="/todo/add" class="btn btn-default">Maak Todo</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>