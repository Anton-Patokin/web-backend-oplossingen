# Laravel Quickstart - Basic

http://laravel.com/docs/quickstart
